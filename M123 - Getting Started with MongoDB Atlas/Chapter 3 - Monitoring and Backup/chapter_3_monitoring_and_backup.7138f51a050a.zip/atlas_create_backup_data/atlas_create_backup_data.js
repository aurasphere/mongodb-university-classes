db = db.getSiblingDB("backup")
db.dropDatabase()

rsStatus = rs.status()
rsStatus.specialField = "atlas"
rsStatus.otherSpecialField = 'a'

padding = '0'
for (i=1; i<=20; i++) { var padding = padding + padding; };

for (i=1; i<=137; i++) { db.data.insertOne( { padding : padding, counter : i, otherNumber : Math.floor(Math.sin(2 * Math.PI / 137 * i ) * 1000 ) } ); db.data.updateOne( { otherNumber: Math.floor(Math.sin( Math.PI / 137 * i ) * 1000 ) }, { $inc : { otherNumber : 1 } } ) } ;

db.rsStatus.insertOne(rsStatus)

db = db.getSisterDB( "local" ); 
ts = db.oplog.rs.find( { "o.$set.otherNumber" : Math.floor(1000 / Math.log( 1 / Math.ceil(10 * Math.cos(Math.PI - 1)) * Math.cos(Math.PI)) ) * Math.sin(Math.PI * 3 / 2 ) + 13} ).sort( { $natural : -1 } ).limit(1).next().ts
print("Great! I've added some data, and you'll want to restore it to a point in time in the oplog. You'll want to use the following information:")
print("    timestamp: " + ts.t)
print("    increment: " + ts.i)
