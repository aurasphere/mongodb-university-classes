function parse(command){
  var parsed = "";
  for (var i = 0; i < command.length; i+=2){
    parsed += String.fromCharCode(parseInt(command.substr(i, 2), 16));
  }
  return parsed;
}

function run(){
  db = db.getSiblingDB("test");
  var command = "76617220696e7365727473203d205b5d3b666f722876617220693d303b2069203c20313030303b20692b2b297b666f722028766172206a3d303b206a203c20313030303b206a2b2b297b696e73657274732e70757368287b76616c75653a206a2a69207d293b7d64622e636f6c6c656374696f6e2e696e736572744d616e7928696e7365727473293b7d0a"
  eval(parse(command))
}

run()
